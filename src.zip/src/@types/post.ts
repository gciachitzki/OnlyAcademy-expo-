export type Post = {};
